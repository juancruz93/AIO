exports.dependencies = ['jshint', 'ddescribe-iit', 'karma'];
