angular.module('docsApp').constant('{$ doc.name $}', {$ doc.items | json $});
