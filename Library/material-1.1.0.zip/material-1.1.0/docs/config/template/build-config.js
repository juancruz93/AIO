angular.module('docsApp').constant('BUILDCONFIG', {$ doc.buildConfig | json $});
